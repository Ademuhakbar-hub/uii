<nav class="navbar navbar-expand-md navbar-light fixed-top bg-light">
    <div class="container-fluid">
        
        <a class="navbar-brand" href="/">
            Sysmantpq
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav me-auto mb-2 mb-md-0 d-flex d-md-none">
                <?php switch(auth()->user()->role):
                    case ('admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(Route::is('admin.home') ? ' active' : ''); ?>" href="<?php echo e(route('admin.home')); ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Kelola Ustad</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Kelola Santri</a>
                        </li>
                        
                        <?php break; ?>
                    <?php case ('ustad'): ?>
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(Route::is('ustad.home') ? ' active' : ''); ?>" href="<?php echo e(route('ustad.home')); ?>">Beranda</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Presensi Ustad</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Presensi Santri</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="">Penilaian Santri</a>
                        </li>
                        <?php break; ?>
                    <?php default: ?>
                        <li class="nav-item">
                            <a class="nav-link<?php echo e(Route::is('home') ? ' active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a>
                        </li>
                <?php endswitch; ?>
            </ul>
            <ul class="navbar-nav ms-auto mb-2 mb-md-0">
                <li class="nav-item my-auto d-none d-md-inline">
                    <span class="align-middle me-1"><b><?php echo e(auth()->user()->username); ?></b></span>
                    <img src="<?php echo e(Avatar::create(auth()->user()->username)->toBase64()); ?>" alt="mdo" width="32" height="32" class="rounded-circle me-2">
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">Keluar</a>
                </li>
                
                
                
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/yogarypr/project/ta-pace/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>