<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('ustad.home')); ?>">Beranda</a></li>
    <li class="breadcrumb-item active" aria-current="page">Presensi Ustad</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Presensi Ustad</h2>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="data-tab" data-bs-toggle="tab" data-bs-target="#data" type="button" role="tab" aria-controls="data" aria-selected="true">Data</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="graph-tab" data-bs-toggle="tab" data-bs-target="#graph" type="button" role="tab" aria-controls="graph" aria-selected="false">Grafik</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="data" role="tabpanel" aria-labelledby="data-tab">
                <h4 class="mt-3 border-bottom border-1 border-primary">Tambah Presensi Ustad</h4>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if($message = Session::get('error')): ?>
                    <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong><?php echo e($message); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('ustad.presensi.add')); ?>" method="POST" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="row my-3">
                        <label for="tanggal" class="col-md-2 col-form-label">Tanggal</label>
                        <div class="col-md-4">
                            <input type="text" id="tanggal" class="form-control-plaintext" value="<?php echo e(Carbon\Carbon::now()->locale('id')->isoFormat('D MMMM Y')); ?>" readonly>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-secondary">Tambah Data Presensi</button>
                </form>
                <h4 class="mt-3 border-bottom border-1 border-primary">Sejarah Presensi Ustad</h4>
                <div class="table-responsive mt-3">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($presensiUstads->count() == 0): ?>
                                <tr>
                                    <td colspan="2" class="text-center text-muted">Belum ada data untuk ditampilkan</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $presensiUstads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $presensiUstad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($presensiUstad->date->locale('id')->isoFormat('dddd, D MMMM Y')); ?></td>
                                        <td>
                                            <?php if($presensiUstad->presence): ?>
                                                <span class="badge bg-success"><i class="fas fa-check me-1"></i>Hadir</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Tidak Hadir</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="graph" role="tabpanel" aria-labelledby="graph-tab">
                <h4 class="mt-3 border-bottom border-1 border-primary">Grafik Presensi Ustad</h4>
                <?php if(count(array_unique($grafikHadir)) === 1 && count(array_unique($grafikTidakHadir)) === 1): ?>
                    <div class="alert alert-warning alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>Belum ada data untuk ditampilkan</strong>
                    </div>
                <?php endif; ?>
                <canvas id="myChart" height="100"></canvas>
            </div>
        </div>

        
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.id.min.js')); ?>"></script>
    <script>
        // $('#month').datepicker({
        //     autoclose: true,
        //     format: 'MM yyyy',
        //     startView: 1,
        //     minViewMode: 1,
        //     endDate: '0d',
        //     orientation: 'bottom',
        // });
        // $('#tanggal').datepicker({
        //     autoclose: true,
        //     format: 'dd-mm-yyyy',
        //     language: 'id',
        //     endDate: '0d',
        //     orientation: 'bottom',
        //     daysOfWeekDisabled: '0,6',
        // });
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
                datasets: [{
                    label: 'Hadir',
                    data: [
                        <?php $__currentLoopData = $grafikHadir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hadir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($hadir); ?>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    backgroundColor: [
                        'rgba(4, 49, 127, 1)',
                    ],
                },{
                    label: 'Tidak Hadir',
                    data: [
                        <?php $__currentLoopData = $grafikTidakHadir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tidakHadir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($tidakHadir); ?>,
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                    backgroundColor: [
                        'rgba(246, 211, 0, 1)',
                    ],
                }]
            },
            options: {
                scales: {
                    y: {
                        suggestedMax: 30,
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yogarypr/project/ta-pace/resources/views/ustad/presensi_ustad.blade.php ENDPATH**/ ?>