<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.dataTables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active" aria-current="page">Kelola Ustad</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Kelola Ustad</h2>
        <h4 class="mt-3 border-bottom border-1 border-primary">Daftar Ustad</h4>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <div class="text-end">
            <a href="<?php echo e(route('admin.ustad.create')); ?>" class="btn btn-primary">Tambah Data</a>
        </div>
        <div class="mt-3">
            <table class="table table-hover table-bordered display responsive nowrap" width="100%" id="ustadTable">
                <thead>
                    <tr>
                        <th>Nama Ustad</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ustads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ustad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($ustad->name); ?></td>
                            <td><?php echo e($ustad->user->username); ?></td>
                            <td><?php echo e($ustad->user->email); ?></td>
                            <td>
                                <?php if($ustad->status): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Tidak Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($ustad->status): ?>
                                    <a href="<?php echo e(route('admin.ustad.show', $ustad->id)); ?>" class="btn btn-sm btn-light">Detail</a>
                                    <a href="<?php echo e(route('admin.ustad.edit', $ustad->id)); ?>" class="btn btn-sm btn-secondary">Ubah</a>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deactModal" data-bs-ustadId="<?php echo e(route('admin.ustad.deact', $ustad->id)); ?>" data-bs-ustadName="<?php echo e($ustad->name); ?>">
                                        Nonaktifkan
                                    </button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#actModal"  data-bs-ustadId="<?php echo e(route('admin.ustad.act', $ustad->id)); ?>" data-bs-ustadName="<?php echo e($ustad->name); ?>">
                                        Aktifkan
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
    <div class="modal fade" id="actModal" tabindex="-1" aria-labelledby="actModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="actModalLabel">Aktifkan Ustad?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" id="actForm">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="actName" class="col-form-label">Anda yakin akan mengaktifkan ustad atas nama</label>
                            <input type="text" class="form-control-plaintext" id="actName" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Aktifkan Ustad</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="deactModal" tabindex="-1" aria-labelledby="deactModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deactModalLabel">Nonaktifkan Ustad?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" id="deactForm">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="deactName" class="col-form-label">Anda yakin akan menonaktifkan ustad atas nama</label>
                            <input type="text" class="form-control-plaintext" id="deactName" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Nonaktifkan Ustad</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
    <script>
        $('#ustadTable').DataTable({
            responsive: true,
            language: {
                url: '<?php echo e(asset('id.json')); ?>',
            },
        });
        var actModal = document.getElementById('actModal')
        actModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget
            var id = button.getAttribute('data-bs-ustadId')
            var name = button.getAttribute('data-bs-ustadName')

            var actForm = actModal.querySelector('#actForm')
            var actName = actModal.querySelector('#actName')

            actForm.action = id
            actName.value = name
        });
        var deactModal = document.getElementById('deactModal')
        deactModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget
            var id = button.getAttribute('data-bs-ustadId')
            var name = button.getAttribute('data-bs-ustadName')

            var deactForm = deactModal.querySelector('#deactForm')
            var deactName = deactModal.querySelector('#deactName')

            deactForm.action = id
            deactName.value = name
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yogarypr/project/ta-pace/resources/views/admin/ustad/index.blade.php ENDPATH**/ ?>