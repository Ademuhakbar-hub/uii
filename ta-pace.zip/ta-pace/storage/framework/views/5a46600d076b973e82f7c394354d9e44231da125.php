<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('ustad.home')); ?>">Beranda</a></li>
    <li class="breadcrumb-item active" aria-current="page">Penilaian Santri</li>
    <li class="breadcrumb-item active" aria-current="page">Iqro</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Penilaian Santri</h2>
        <ul class="nav nav-tabs mt-3">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('ustad.santri.penilaian.quran')); ?>">Al-Qur'an</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page">Iqro</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('ustad.santri.penilaian.hafalan')); ?>">Hafalan</a>
            </li>
        </ul>
        <h4 class="mt-3 border-bottom border-1 border-primary">Tambah Penilaian Santri</h4>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('ustad.santri.penilaian.iqro.add')); ?>" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="row my-3">
              <label for="santri" class="col-md-2 col-form-label">Nama Santri</label>
              <div class="col-md-4">
                <select class="form-select" aria-label="Pilih Santri" id="santri" name="santri" required>
                    <option disabled selected>Pilih Santri</option>
                    <?php $__currentLoopData = $santris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $santri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($santri->id); ?>"><?php echo e($santri->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="row mb-3">
                <label for="tanggal" class="col-md-2 col-form-label">Tanggal</label>
                <div class="col-md-4">
                    <input type="text" id="tanggal" name="tanggal" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="keterangan" class="col-md-2 col-form-label">Keterangan</label>
                <div class="col-md-4">
                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3" placeholder="contoh: Iqro 3, hal 5" required></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-secondary">Tambah Data</button>
        </form>
        <h4 class="mt-3 border-bottom border-1 border-primary">Sejarah Penilaian Santri</h4>
        <div class="table-responsive mt-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Nama Santri</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($penilaianSantriIqros->count() == 0): ?>
                        <tr>
                            <td colspan="3" class="text-center text-muted">Belum ada data untuk ditampilkan</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $penilaianSantriIqros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaianSantriIqro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($penilaianSantriIqro->date->locale('id')->isoFormat('dddd, D MMMM Y')); ?></td>
                                <td><?php echo e($penilaianSantriIqro->santri->name); ?></td>
                                <td><?php echo e($penilaianSantriIqro->keterangan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.id.min.js')); ?>"></script>
    <script>
        $('#tanggal').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            language: 'id',
            endDate: '0d',
            orientation: 'bottom',
            daysOfWeekDisabled: '0,6',
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yogarypr/project/ta-pace/resources/views/ustad/penilaian_santri_iqro.blade.php ENDPATH**/ ?>