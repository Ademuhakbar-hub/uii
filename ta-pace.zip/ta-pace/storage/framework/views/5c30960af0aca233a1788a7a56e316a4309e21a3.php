<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name')); ?></title>
        <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/png">

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldPushContent('style'); ?>
    </head>
    <body class="bg-light">
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="container-fluid mt-5 pt-4">
            <div class="card-body bg-white">
                <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <?php echo $__env->yieldContent('breadcrumb'); ?>
                        
                    </ol>
                </nav>
            </div>
            <div class="row mt-3">
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-9">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </main>
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="logoutModalLabel">Keluar dari Sistem</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Anda yakin akan keluar dari sistem?
                    </div>
                    <div class="modal-footer border-top-0">
                        <a href="#" class="btn btn-light" data-bs-dismiss="modal">Batal</a>
                        <a href="<?php echo e(route('logout')); ?>" class="btn btn-primary"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            Keluar
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->yieldPushContent('modal'); ?>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html>
<?php /**PATH /home/yogarypr/project/ta-pace/resources/views/layouts/app.blade.php ENDPATH**/ ?>