<div class="d-none d-md-block col-md-3">
    <div class="card card-body">
        <ul class="nav nav-pills flex-column">
            <?php switch(auth()->user()->role):
                case ('admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('admin.home') ? ' active' : ''); ?>" href="<?php echo e(route('admin.home')); ?>">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('admin.ustad*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.ustad')); ?>">Kelola Ustad</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('admin.santri*') ? ' active' : ''); ?>" href="<?php echo e(route('admin.santri')); ?>">Kelola Santri</a>
                    </li>
                    
                    <?php break; ?>
                <?php case ('ustad'): ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('ustad.home') ? ' active' : ''); ?>" href="<?php echo e(route('ustad.home')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('ustad.presensi') ? ' active' : ''); ?>" href="<?php echo e(route('ustad.presensi')); ?>">Presensi Ustad</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('ustad.santri.presensi') ? ' active' : ''); ?>" href="<?php echo e(route('ustad.santri.presensi')); ?>">Presensi Santri</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('ustad.santri.penilaian*') ? ' active' : ''); ?>" href="<?php echo e(route('ustad.santri.penilaian.quran')); ?>">Penilaian Santri</a>
                    </li>
                    <?php break; ?>
                <?php default: ?>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('home') ? ' active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('presensi') ? ' active' : ''); ?>" href="<?php echo e(route('presensi')); ?>">Presensi Santri</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link<?php echo e(Route::is('penilaian*') ? ' active' : ''); ?>" href="<?php echo e(route('penilaian.quran')); ?>">Penilaian Santri</a>
                    </li>
            <?php endswitch; ?>
        </ul>
    </div>
</div>
<?php /**PATH /home/yogarypr/project/ta-pace/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>