<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active" aria-current="page">Beranda</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card card-body">
        <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong><?php echo e($message); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <h2 class="mt-3 border-bottom border-3 border-secondary">Data Induk Ustad</h2>
        <table class="table table-borderless mt-1">
            <tr>
                <th width="20%">Nama Lengkap</th>
                <td>: <?php echo e(auth()->user()->ustad->name); ?></td>
            </tr>
            <tr>
                <th width="20%">Tempat Lahir</th>
                <td>: <?php echo e(auth()->user()->ustad->tempat_lahir); ?></td>
            </tr>
            <tr>
                <th width="20%">Tanggal Lahir</th>
                <td>: <?php echo e(auth()->user()->ustad->tanggal_lahir->locale('id')->isoFormat('D MMMM Y')); ?></td>
            </tr>
            <tr>
                <th width="20%">Jenis Kelamin</th>
                <td>: <?php echo e(auth()->user()->ustad->jenis_kelamin); ?></td>
            </tr>
            <tr>
                <th width="20%">Alamat</th>
                <td>: <?php echo e(auth()->user()->ustad->alamat); ?></td>
            </tr>
            <tr>
                <th width="20%">Pendidikan Terakhir</th>
                <td>: <?php echo e(auth()->user()->ustad->pendidikan_terakhir); ?></td>
            </tr>
            <tr>
                <th width="20%">Status</th>
                <td>:
                    <?php if(auth()->user()->ustad->status): ?>
                        <span class="badge bg-success">Aktif</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Tidak Aktif</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th width="20%">No HP</th>
                <td>: <?php echo e(auth()->user()->ustad->no_hp); ?></td>
            </tr>
        </table>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yogarypr/project/ta-pace/resources/views/ustad/home.blade.php ENDPATH**/ ?>