<?php

namespace App\Http\Controllers\Ustad;

use App\Http\Controllers\Controller;
use App\Models\PresensiSantri;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;

class PresensiSantriController extends Controller
{
    public function index()
    {
        $santris = auth()->user()->ustad->santris;
        if ($santris->count() == 0) {
            return redirect(route('ustad.home'))->with('error', 'Belum ada data santri yang terintegrasi, silahkan hubungi admin');
        }
        $monthName = Carbon::now()->locale('id')->isoFormat('MMMM');
        $carbonMonth = CarbonPeriod::create(Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth());
        $presensiLabels = array();
        foreach ($carbonMonth as $carbonDay) {
            $presensiLabels[] = $carbonDay->format('d');
        }
        $grafikHadir = array_fill(0, count($presensiLabels), 0);
        $grafikTidakHadir = array_fill(0, count($presensiLabels), 0);
        $presensiSantris = false;
        foreach ($carbonMonth as $carbonDay) {
            if (auth()->user()->ustad->presensiSantris()->where('date', $carbonDay)->exists()) {
                $presensiSantris = auth()->user()->ustad->presensiSantris()->where('date', $carbonDay)->get();
                foreach ($presensiSantris as $presensi) {
                    if ($presensi->presence) {
                        $grafikHadir[$presensi->date->day - 1] += 1;
                    } else {
                        $grafikTidakHadir[$presensi->date->day - 1] += 1;
                    }
                }
            }
        }
        return view('ustad.presensi_santri', compact('santris', 'presensiSantris', 'grafikHadir', 'grafikTidakHadir', 'presensiLabels', 'monthName'));
    }

    public function addPresence(Request $request)
    {
        if (PresensiSantri::where('ustad_id', auth()->user()->ustad->id)->whereDate('date', Carbon::now())->exists()) {
            return redirect()->back()->with('error', 'Anda sudah melakukan presensi hari ini!');
        } elseif ($request->has('check')) {
            foreach (auth()->user()->ustad->santris as $santri) {
                if (array_key_exists($santri->id, $request->check)) {
                    $presensiSantri = PresensiSantri::create([
                        'ustad_id' => auth()->user()->ustad->id,
                        'santri_id' => $santri->id,
                        'date' => Carbon::now(),
                        'presence' => true
                    ]);
                    $presensiSantri->save();
                } else {
                    $presensiSantri = PresensiSantri::create([
                        'ustad_id' => auth()->user()->ustad->id,
                        'santri_id' => $santri->id,
                        'date' => Carbon::now(),
                        'presence' => false
                    ]);
                    $presensiSantri->save();
                }
            }
            return redirect()->back()->with('success', 'Data presensi santri berhasil ditambahkan!');
        } else {
            foreach (auth()->user()->ustad->santris as $santri) {
                $presensiSantri = PresensiSantri::create([
                    'ustad_id' => auth()->user()->ustad->id,
                    'santri_id' => $santri->id,
                    'date' => Carbon::now(),
                    'presence' => false
                ]);
                $presensiSantri->save();
            }
            return redirect()->back()->with('success', 'Data presensi santri berhasil ditambahkan!');
        }

        // if (!$request->has('santri')) {
        //     return redirect()->back()->with('error', 'Silahkan pilih santri terlebih dahulu');
        // }
        // if (PresensiSantri::where('santri_id', $request->santri)->where('ustad_id', auth()->user()->ustad->id)->whereDate('date', Carbon::createFromFormat('d-m-Y', $request->tanggal))->exists()) {
        //     $presensiUstad = PresensiSantri::where('santri_id', $request->santri)->where('ustad_id', auth()->user()->ustad->id)->whereDate('date', Carbon::createFromFormat('d-m-Y', $request->tanggal))->first();
        //     if ($request->hadirRadio) {
        //         $presensiUstad->presence = true;
        //     } else {
        //         $presensiUstad->presence = false;
        //     }
        //     $presensiUstad->save();
        //     return redirect()->back()->with('success', 'Data presensi santri tanggal '.$request->tanggal.' berhasil diperbarui!');
        // } else {
        //     if ($request->hadirRadio) {
        //         $presensiUstad = PresensiSantri::create([
        //             'ustad_id' => auth()->user()->ustad->id,
        //             'santri_id' => $request->santri,
        //             'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
        //             'presence' => true
        //         ]);
        //         $presensiUstad->save();
        //         return redirect()->back()->with('success', 'Data presensi santri tanggal '.$request->tanggal.' berhasil ditambahkan!');
        //     } else {
        //         $presensiUstad = PresensiSantri::create([
        //             'ustad_id' => auth()->user()->ustad->id,
        //             'santri_id' => $request->santri,
        //             'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
        //             'presence' => false
        //         ]);
        //         $presensiUstad->save();
        //         return redirect()->back()->with('success', 'Data presensi santri tanggal '.$request->tanggal.' berhasil ditambahkan!');
        //     }
        // }
    }
}
