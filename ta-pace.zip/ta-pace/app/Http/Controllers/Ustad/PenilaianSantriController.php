<?php

namespace App\Http\Controllers\Ustad;

use App\Http\Controllers\Controller;
use App\Models\PenilaianSantriHafalan;
use App\Models\PenilaianSantriIqro;
use App\Models\PenilaianSantriQuran;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PenilaianSantriController extends Controller
{
    public function indexQuran()
    {
        $santris = auth()->user()->ustad->santris;
        if ($santris->count() == 0) {
            return redirect(route('ustad.home'))->with('error', 'Belum ada data santri yang terintegrasi, silahkan hubungi admin');
        }
        $penilaianSantriQurans = auth()->user()->ustad->penilaianSantriQurans()->latest('date')->get();
        return view('ustad.penilaian_santri_quran', compact('santris', 'penilaianSantriQurans'));
    }

    public function indexQuranAdd(Request $request)
    {
        if (!$request->has('santri')) {
            return redirect()->back()->with('error', 'Silahkan pilih santri terlebih dahulu');
        }
        $penilaianSantriQuran = PenilaianSantriQuran::create([
            'ustad_id' => auth()->user()->ustad->id,
            'santri_id' => $request->santri,
            'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
            'keterangan' => $request->keterangan
        ]);
        $penilaianSantriQuran->save();
        return redirect()->back()->with('success', 'Data penilaian Al-Quran santri tanggal '.$request->tanggal.' berhasil ditambahkan!');
    }

    public function indexIqro()
    {
        $santris = auth()->user()->ustad->santris;
        if ($santris->count() == 0) {
            return redirect(route('ustad.home'))->with('error', 'Belum ada data santri yang terintegrasi, silahkan hubungi admin');
        }
        $penilaianSantriIqros = auth()->user()->ustad->penilaianSantriIqros()->latest('date')->get();
        return view('ustad.penilaian_santri_iqro', compact('santris', 'penilaianSantriIqros'));
    }

    public function indexIqroAdd(Request $request)
    {
        if (!$request->has('santri')) {
            return redirect()->back()->with('error', 'Silahkan pilih santri terlebih dahulu');
        }
        $penilaianSantriIqro = PenilaianSantriIqro::create([
            'ustad_id' => auth()->user()->ustad->id,
            'santri_id' => $request->santri,
            'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
            'keterangan' => $request->keterangan
        ]);
        $penilaianSantriIqro->save();
        return redirect()->back()->with('success', 'Data penilaian Iqro santri tanggal '.$request->tanggal.' berhasil ditambahkan!');
    }

    public function indexHafalan()
    {
        $santris = auth()->user()->ustad->santris;
        if ($santris->count() == 0) {
            return redirect(route('ustad.home'))->with('error', 'Belum ada data santri yang terintegrasi, silahkan hubungi admin');
        }
        $penilaianSantriHafalans = auth()->user()->ustad->penilaianSantriHafalans()->latest('date')->get();
        return view('ustad.penilaian_santri_hafalan', compact('santris', 'penilaianSantriHafalans'));
    }

    public function indexHafalanAdd(Request $request)
    {
        if (!$request->has('santri')) {
            return redirect()->back()->with('error', 'Silahkan pilih santri terlebih dahulu');
        }
        $penilaianSantriHafalan = PenilaianSantriHafalan::create([
            'ustad_id' => auth()->user()->ustad->id,
            'santri_id' => $request->santri,
            'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
            'surat' => $request->surat,
            'keterangan' => $request->keterangan
        ]);
        $penilaianSantriHafalan->save();
        return redirect()->back()->with('success', 'Data penilaian Hafalan santri tanggal '.$request->tanggal.' berhasil ditambahkan!');
    }
}
