<?php

namespace App\Http\Controllers\Ustad;

use App\Http\Controllers\Controller;
use App\Models\PresensiUstad;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PresensiUstadController extends Controller
{
    // public function index(Request $request)
    // {
    //     $year = Carbon::now()->format('Y');
    //     $month = Carbon::now()->format('m');
    //     $monthName = Carbon::now()->locale('id')->isoFormat('MMMM Y');
    //     $endDate = (int) Carbon::now()->endOfMonth()->format('d');
    //     $startTab = (int) Carbon::now()->startOfMonth()->isoFormat('d');
    //     if ($request->has('month') && $request->month != null) {
    //         $year = Carbon::createFromIsoFormat('MMMM Y', $request->month)->format('Y');
    //         $month = Carbon::createFromIsoFormat('MMMM Y', $request->month)->format('m');
    //         $monthName = Carbon::createFromIsoFormat('MMMM Y', $request->month)->locale('id')->isoFormat('MMMM Y');
    //         $endDate = (int) Carbon::createFromIsoFormat('MMMM Y', $request->month)->endOfMonth()->format('d');
    //         $startTab = (int) Carbon::createFromIsoFormat('MMMM Y', $request->month)->startOfMonth()->isoFormat('d');
    //     }
    //     $startDate = 1;
    //     if ($startTab == 6) {
    //         $startDate = 3;
    //         $startTab = 1;
    //     } else if ($startTab == 0) {
    //         $startDate = 2;
    //         $startTab = 1;
    //     }
    //     $presensiUstads = PresensiUstad::where('ustad_id', auth()->user()->ustad->id)->whereYear('date', $year)->whereMonth('date', $month);
    //     return view('ustad.presensi_ustad', compact('presensiUstads', 'monthName', 'endDate', 'startDate', 'startTab'));
    // }

    public function index()
    {
        $presensiUstads = auth()->user()->ustad->presensiUstads()->latest('date')->get();
        $grafikHadir = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        $grafikTidakHadir = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        foreach ($presensiUstads as $presensi) {
            if ($presensi->presence) {
                $grafikHadir[$presensi->date->month - 1] += 1;
            } else {
                $grafikTidakHadir[$presensi->date->month - 1] += 1;
            }
        }
        return view('ustad.presensi_ustad', compact('presensiUstads', 'grafikHadir', 'grafikTidakHadir'));
    }

    public function addPresence(Request $request)
    {
        if (PresensiUstad::where('ustad_id', auth()->user()->ustad->id)->whereDate('date', Carbon::now())->exists()) {
            return redirect()->back()->with('error', 'Anda sudah melakukan presensi hari ini!');
        } else {
            $presensiUstad = PresensiUstad::create([
                'ustad_id' => auth()->user()->ustad->id,
                'date' => Carbon::now(),
                'presence' => true
            ]);
            $presensiUstad->save();
            return redirect()->back()->with('success', 'Data presensi anda berhasil ditambahkan!');
        }

        // if (PresensiUstad::where('ustad_id', auth()->user()->ustad->id)->whereDate('date', Carbon::createFromFormat('d-m-Y', $request->tanggal))->exists()) {
        //     $presensiUstad = PresensiUstad::where('ustad_id', auth()->user()->ustad->id)->whereDate('date', Carbon::createFromFormat('d-m-Y', $request->tanggal))->first();
        //     if ($request->hadirRadio) {
        //         $presensiUstad->presence = true;
        //     } else {
        //         $presensiUstad->presence = false;
        //     }
        //     $presensiUstad->save();
        //     return redirect()->back()->with('success', 'Data presensi ustad tanggal '.$request->tanggal.' berhasil diperbarui!');
        // } else {
        //     if ($request->hadirRadio) {
        //         $presensiUstad = PresensiUstad::create([
        //             'ustad_id' => auth()->user()->ustad->id,
        //             'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
        //             'presence' => true
        //         ]);
        //         $presensiUstad->save();
        //         return redirect()->back()->with('success', 'Data presensi ustad tanggal '.$request->tanggal.' berhasil ditambahkan!');
        //     } else {
        //         $presensiUstad = PresensiUstad::create([
        //             'ustad_id' => auth()->user()->ustad->id,
        //             'date' => Carbon::createFromFormat('d-m-Y', $request->tanggal),
        //             'presence' => false
        //         ]);
        //         $presensiUstad->save();
        //         return redirect()->back()->with('success', 'Data presensi ustad tanggal '.$request->tanggal.' berhasil ditambahkan!');
        //     }
        // }

    }
}
