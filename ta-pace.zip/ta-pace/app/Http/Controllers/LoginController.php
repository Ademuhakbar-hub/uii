<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        if (Auth::attempt(['username' => $request->username, 'password' => $request->password], $request->filled('remember'))) {
            switch (auth()->user()->role) {
                case 'admin':
                    return redirect()->route('admin.home');
                    break;
                case 'ustad':
                    return redirect()->route('ustad.home');
                    break;
                default:
                    return redirect()->route('home');
                    break;
            }
        } else {
            return redirect()->back()->with('error', 'Kredensial yang anda masukkan tidak sesuai');
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('showLoginForm');
    }
}
