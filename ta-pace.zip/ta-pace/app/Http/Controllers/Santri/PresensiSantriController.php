<?php

namespace App\Http\Controllers\Santri;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PresensiSantriController extends Controller
{
    public function index()
    {
        $presensiSantris = auth()->user()->santri->presensiSantris()->latest('date')->get();
        $grafikHadir = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        $grafikTidakHadir = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        foreach ($presensiSantris as $presensi) {
            if ($presensi->presence) {
                $grafikHadir[$presensi->date->month - 1] += 1;
            } else {
                $grafikTidakHadir[$presensi->date->month - 1] += 1;
            }
        }
        return view('santri.presensi_santri', compact('presensiSantris', 'grafikHadir', 'grafikTidakHadir'));
    }
}
