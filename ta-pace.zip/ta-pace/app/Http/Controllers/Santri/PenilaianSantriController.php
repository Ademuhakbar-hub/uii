<?php

namespace App\Http\Controllers\Santri;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PenilaianSantriController extends Controller
{
    public function indexQuran()
    {
        $penilaianSantriQurans = auth()->user()->santri->penilaianSantriQurans()->latest('date')->get();
        return view('santri.penilaian_santri_quran', compact('penilaianSantriQurans'));
    }

    public function indexIqro()
    {
        $penilaianSantriIqros = auth()->user()->santri->penilaianSantriIqros()->latest('date')->get();
        return view('santri.penilaian_santri_iqro', compact('penilaianSantriIqros'));
    }

    public function indexHafalan()
    {
        $penilaianSantriHafalans = auth()->user()->santri->penilaianSantriHafalans()->latest('date')->get();
        return view('santri.penilaian_santri_hafalan', compact('penilaianSantriHafalans'));
    }
}
