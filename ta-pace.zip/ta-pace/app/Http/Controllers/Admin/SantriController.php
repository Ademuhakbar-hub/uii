<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Santri;
use App\Models\User;
use App\Models\Ustad;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SantriController extends Controller
{
    public function index()
    {
        $santris = Santri::all();
        return view('admin.santri.index', compact('santris'));
    }

    public function create()
    {
        $ustads = Ustad::all();
        return view('admin.santri.create', compact('ustads'));
    }

    public function store(Request $request)
    {
        if (User::where('username', $request->username)->exists()) {
            return redirect()->back()->with('error', 'Username yang anda masukkan sudah digunakan!');
        }

        if (User::where('email', $request->email)->exists()) {
            return redirect()->back()->with('error', 'E-mail yang anda masukkan sudah digunakan!');
        }

        $user = User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'santri'
        ]);

        $user->santri()->create([
            'ustad_id' => $request->ustad,
            'name' => $request->name,
            'tempat_lahir' => $request->tempat_lahir,
            'tanggal_lahir' => Carbon::createFromFormat('d-m-Y', $request->tanggal_lahir),
            'jenis_kelamin' => $request->jenis_kelamin,
            'alamat' => $request->alamat,
            'pendidikan_terakhir' => $request->pendidikan_terakhir,
            'status' => true,
            'no_hp' => $request->no_hp
        ]);

        $user->save();

        return redirect()->route('admin.santri.show', $user->santri->id)->with('success', 'Santri atas nama '.$user->santri->name.' berhasil ditambahkan!');
    }

    public function show(Santri $santri)
    {
        return view('admin.santri.show', compact('santri'));
    }

    public function edit(Santri $santri)
    {
        $ustads = Ustad::all();
        return view('admin.santri.edit', compact('santri', 'ustads'));
    }

    public function update(Request $request, Santri $santri)
    {
        $santri->update([
            'name' => $request->name,
            'tempat_lahir' => $request->tempat_lahir,
            'tanggal_lahir' => Carbon::createFromFormat('d-m-Y', $request->tanggal_lahir),
            'jenis_kelamin' => $request->jenis_kelamin,
            'alamat' => $request->alamat,
            'pendidikan_terakhir' => $request->pendidikan_terakhir,
            'no_hp' => $request->no_hp
        ]);

        return redirect()->route('admin.santri.show', $santri->id)->with('success', 'Santri atas nama '.$santri->name.' berhasil diperbarui!');
    }

    public function activate(Santri $santri)
    {
        $santri->update([
            'status' => true,
        ]);

        return redirect()->route('admin.santri.show', $santri->id)->with('success', 'Santri atas nama '.$santri->name.' berhasil diaktifkan!');
    }

    public function deactivate(Santri $santri)
    {
        $ustad->update([
            'status' => false,
        ]);

        return redirect()->route('admin.santri')->with('success', 'Santri atas nama '.$santri->name.' berhasil dinonaktifkan!');
    }
}
