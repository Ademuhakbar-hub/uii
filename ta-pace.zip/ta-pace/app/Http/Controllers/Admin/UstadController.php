<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Ustad;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UstadController extends Controller
{
    public function index()
    {
        $ustads = Ustad::all();
        return view('admin.ustad.index', compact('ustads'));
    }

    public function create()
    {
        return view('admin.ustad.create');
    }

    public function store(Request $request)
    {
        if (User::where('username', $request->username)->exists()) {
            return redirect()->back()->with('error', 'Username yang anda masukkan sudah digunakan!');
        }

        if (User::where('email', $request->email)->exists()) {
            return redirect()->back()->with('error', 'E-mail yang anda masukkan sudah digunakan!');
        }

        $user = User::create([
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'ustad'
        ]);

        $user->ustad()->create([
            'name' => $request->name,
            'tempat_lahir' => $request->tempat_lahir,
            'tanggal_lahir' => Carbon::createFromFormat('d-m-Y', $request->tanggal_lahir),
            'jenis_kelamin' => $request->jenis_kelamin,
            'alamat' => $request->alamat,
            'pendidikan_terakhir' => $request->pendidikan_terakhir,
            'status' => true,
            'no_hp' => $request->no_hp
        ]);

        $user->save();

        return redirect()->route('admin.ustad.show', $user->ustad->id)->with('success', 'Ustad atas nama '.$user->ustad->name.' berhasil ditambahkan!');
    }

    public function show(Ustad $ustad)
    {
        return view('admin.ustad.show', compact('ustad'));
    }

    public function edit(Ustad $ustad)
    {
        return view('admin.ustad.edit', compact('ustad'));
    }

    public function update(Request $request, Ustad $ustad)
    {
        $ustad->update([
            'name' => $request->name,
            'tempat_lahir' => $request->tempat_lahir,
            'tanggal_lahir' => Carbon::createFromFormat('d-m-Y', $request->tanggal_lahir),
            'jenis_kelamin' => $request->jenis_kelamin,
            'alamat' => $request->alamat,
            'pendidikan_terakhir' => $request->pendidikan_terakhir,
            'no_hp' => $request->no_hp
        ]);

        return redirect()->route('admin.ustad.show', $ustad->id)->with('success', 'Ustad atas nama '.$ustad->name.' berhasil diperbarui!');
    }

    public function activate(Ustad $ustad)
    {
        $ustad->update([
            'status' => true,
        ]);

        return redirect()->route('admin.ustad.show', $ustad->id)->with('success', 'Ustad atas nama '.$ustad->name.' berhasil diaktifkan!');
    }

    public function deactivate(Ustad $ustad)
    {
        $ustad->update([
            'status' => false,
        ]);

        return redirect()->route('admin.ustad')->with('success', 'Ustad atas nama '.$ustad->name.' berhasil dinonaktifkan!');
    }
}
