<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PresensiSantri extends Model
{
    use HasFactory;

    protected $fillable = [
        'ustad_id',
        'santri_id',
        'date',
        'presence',
    ];

    protected $casts = [
        'date' => 'date',
        'presence' => 'boolean',
    ];

    public function santri()
    {
        return $this->belongsTo(Santri::class);
    }

    public function ustad()
    {
        return $this->belongsTo(Ustad::class);
    }
}
