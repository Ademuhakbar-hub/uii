<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ustad extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'name',
        'tempat_lahir',
        'tanggal_lahir',
        'jenis_kelamin',
        'alamat',
        'pendidikan_terakhir',
        'status',
        'no_hp'
    ];

    protected $casts = [
        'tanggal_lahir' => 'date',
        'status' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function santris()
    {
        return $this->hasMany(Santri::class);
    }

    public function presensiUstads()
    {
        return $this->hasMany(PresensiUstad::class);
    }

    public function presensiSantris()
    {
        return $this->hasMany(PresensiSantri::class);
    }

    public function penilaianSantriQurans()
    {
        return $this->hasMany(PenilaianSantriQuran::class);
    }

    public function penilaianSantriIqros()
    {
        return $this->hasMany(PenilaianSantriIqro::class);
    }

    public function penilaianSantriHafalans()
    {
        return $this->hasMany(PenilaianSantriHafalan::class);
    }
}
