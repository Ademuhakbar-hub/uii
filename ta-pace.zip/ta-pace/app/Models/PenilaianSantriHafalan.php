<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PenilaianSantriHafalan extends Model
{
    use HasFactory;

    protected $fillable = [
        'ustad_id',
        'santri_id',
        'date',
        'surat',
        'keterangan',
    ];

    protected $casts = [
        'date' => 'date',
    ];

    public function santri()
    {
        return $this->belongsTo(Santri::class);
    }

    public function ustad()
    {
        return $this->belongsTo(Ustad::class);
    }
}
