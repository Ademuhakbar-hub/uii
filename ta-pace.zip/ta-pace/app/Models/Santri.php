<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Santri extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'ustad_id',
        'name',
        'tempat_lahir',
        'tanggal_lahir',
        'jenis_kelamin',
        'alamat',
        'pendidikan_terakhir',
        'status',
        'no_hp'
    ];

    protected $casts = [
        'tanggal_lahir' => 'date',
        'status' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function ustad()
    {
        return $this->belongsTo(Ustad::class);
    }

    public function presensiSantris()
    {
        return $this->hasMany(PresensiSantri::class);
    }

    public function penilaianSantriQurans()
    {
        return $this->hasMany(PenilaianSantriQuran::class);
    }

    public function penilaianSantriIqros()
    {
        return $this->hasMany(PenilaianSantriIqro::class);
    }

    public function penilaianSantriHafalans()
    {
        return $this->hasMany(PenilaianSantriHafalan::class);
    }
}
