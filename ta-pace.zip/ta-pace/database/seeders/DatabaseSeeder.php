<?php

namespace Database\Seeders;

use App\Models\Santri;
use App\Models\User;
use App\Models\Ustad;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        User::insert([
            [
                'username' => 'admin1',
                'email' => 'admin1@mail.com',
                'password' => Hash::make('12345678'),
                'role' => 'admin'
            ],
            [
                'username' => 'ustad1',
                'email' => 'ustad1@mail.com',
                'password' => Hash::make('12345678'),
                'role' => 'ustad'
            ],
            [
                'username' => 'santri1',
                'email' => 'santri1@mail.com',
                'password' => Hash::make('12345678'),
                'role' => 'santri'
            ],
            [
                'username' => 'santri2',
                'email' => 'santri2@mail.com',
                'password' => Hash::make('12345678'),
                'role' => 'santri'
            ],
            [
                'username' => 'santri3',
                'email' => 'santri3@mail.com',
                'password' => Hash::make('12345678'),
                'role' => 'santri'
            ]
        ]);

        Ustad::insert([
            [
                'user_id' => 2,
                'name' => 'Ustad Hidayah',
                'tempat_lahir' => 'Sleman',
                'tanggal_lahir' => Carbon::now()->subYears(28),
                'jenis_kelamin' => 'Laki-laki',
                'alamat' => 'Jl. Kaliurang km 14',
                'pendidikan_terakhir' => 'S1',
                'status' => true,
                'no_hp' => '08123456789'
            ]
        ]);

        Santri::insert([
            [
                'user_id' => 3,
                'ustad_id' => 1,
                'name' => 'Ahmad',
                'tempat_lahir' => 'Sleman',
                'tanggal_lahir' => Carbon::now()->subYears(19),
                'jenis_kelamin' => 'Laki-laki',
                'alamat' => 'Jl. Kaliurang km 13',
                'pendidikan_terakhir' => 'SMP Kelas 3',
                'status' => true,
                'no_hp' => '08123456788'
            ],
            [
                'user_id' => 4,
                'ustad_id' => 1,
                'name' => 'Akbar',
                'tempat_lahir' => 'Sleman',
                'tanggal_lahir' => Carbon::now()->subYears(17),
                'jenis_kelamin' => 'Laki-laki',
                'alamat' => 'Jl. Kaliurang km 13',
                'pendidikan_terakhir' => 'SMP Kelas 1',
                'status' => true,
                'no_hp' => '08123456787'
            ],
            [
                'user_id' => 5,
                'ustad_id' => 1,
                'name' => 'Ilham',
                'tempat_lahir' => 'Sleman',
                'tanggal_lahir' => Carbon::now()->subYears(10),
                'jenis_kelamin' => 'Laki-laki',
                'alamat' => 'Jl. Kaliurang km 13',
                'pendidikan_terakhir' => 'SD Kelas 6',
                'status' => true,
                'no_hp' => '-'
            ]
        ]);
    }
}
