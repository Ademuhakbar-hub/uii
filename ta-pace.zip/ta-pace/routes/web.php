<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/login', 'LoginController@showLoginForm')->name('showLoginForm')->middleware('guest');
Route::post('/login', 'LoginController@login')->name('login')->middleware('guest');

Route::post('/logout', 'LoginController@logout')->name('logout')->middleware('auth');


Route::get('/', 'Santri\HomeController@index')->name('home')->middleware(['auth', 'santri']);
Route::get('/presensi', 'Santri\PresensiSantriController@index')->name('presensi')->middleware(['auth', 'santri']);
Route::get('/penilaian/quran', 'Santri\PenilaianSantriController@indexQuran')->name('penilaian.quran')->middleware(['auth', 'santri']);
Route::get('/penilaian/iqro', 'Santri\PenilaianSantriController@indexIqro')->name('penilaian.iqro')->middleware(['auth', 'santri']);
Route::get('/penilaian/hafalan', 'Santri\PenilaianSantriController@indexHafalan')->name('penilaian.hafalan')->middleware(['auth', 'santri']);


Route::get('/ustad', 'Ustad\HomeController@index')->name('ustad.home')->middleware(['auth', 'ustad']);

Route::get('/ustad/presensi', 'Ustad\PresensiUstadController@index')->name('ustad.presensi')->middleware(['auth', 'ustad']);
Route::post('/ustad/presensi/add', 'Ustad\PresensiUstadController@addPresence')->name('ustad.presensi.add')->middleware(['auth', 'ustad']);

Route::get('/ustad/santri/presensi', 'Ustad\PresensiSantriController@index')->name('ustad.santri.presensi')->middleware(['auth', 'ustad']);
Route::post('/ustad/santri/presensi/add', 'Ustad\PresensiSantriController@addPresence')->name('ustad.santri.presensi.add')->middleware(['auth', 'ustad']);

Route::get('/ustad/santri/penilaian/quran', 'Ustad\PenilaianSantriController@indexQuran')->name('ustad.santri.penilaian.quran')->middleware(['auth', 'ustad']);
Route::post('/ustad/santri/penilaian/quran/add', 'Ustad\PenilaianSantriController@indexQuranAdd')->name('ustad.santri.penilaian.quran.add')->middleware(['auth', 'ustad']);
Route::get('/ustad/santri/penilaian/iqro', 'Ustad\PenilaianSantriController@indexIqro')->name('ustad.santri.penilaian.iqro')->middleware(['auth', 'ustad']);
Route::post('/ustad/santri/penilaian/iqro/add', 'Ustad\PenilaianSantriController@indexIqroAdd')->name('ustad.santri.penilaian.iqro.add')->middleware(['auth', 'ustad']);
Route::get('/ustad/santri/penilaian/hafalan', 'Ustad\PenilaianSantriController@indexHafalan')->name('ustad.santri.penilaian.hafalan')->middleware(['auth', 'ustad']);
Route::post('/ustad/santri/penilaian/hafalan/add', 'Ustad\PenilaianSantriController@indexHafalanAdd')->name('ustad.santri.penilaian.hafalan.add')->middleware(['auth', 'ustad']);


Route::get('/admin', 'Admin\HomeController@index')->name('admin.home')->middleware(['auth', 'admin']);

Route::get('/admin/ustad', 'Admin\UstadController@index')->name('admin.ustad')->middleware(['auth', 'admin']);
Route::get('/admin/ustad/create', 'Admin\UstadController@create')->name('admin.ustad.create')->middleware(['auth', 'admin']);
Route::post('/admin/ustad/store', 'Admin\UstadController@store')->name('admin.ustad.store')->middleware(['auth', 'admin']);
Route::get('/admin/ustad/show/{ustad}', 'Admin\UstadController@show')->name('admin.ustad.show')->middleware(['auth', 'admin']);
Route::get('/admin/ustad/edit/{ustad}', 'Admin\UstadController@edit')->name('admin.ustad.edit')->middleware(['auth', 'admin']);
Route::put('/admin/ustad/update/{ustad}', 'Admin\UstadController@update')->name('admin.ustad.update')->middleware(['auth', 'admin']);
Route::put('/admin/ustad/activate/{ustad}', 'Admin\UstadController@activate')->name('admin.ustad.act')->middleware(['auth', 'admin']);
Route::delete('/admin/ustad/deactivate/{ustad}', 'Admin\UstadController@deactivate')->name('admin.ustad.deact')->middleware(['auth', 'admin']);

Route::get('/admin/santri', 'Admin\SantriController@index')->name('admin.santri')->middleware(['auth', 'admin']);
Route::get('/admin/santri/create', 'Admin\SantriController@create')->name('admin.santri.create')->middleware(['auth', 'admin']);
Route::post('/admin/santri/store', 'Admin\SantriController@store')->name('admin.santri.store')->middleware(['auth', 'admin']);
Route::get('/admin/santri/show/{santri}', 'Admin\SantriController@show')->name('admin.santri.show')->middleware(['auth', 'admin']);
Route::get('/admin/santri/edit/{santri}', 'Admin\SantriController@edit')->name('admin.santri.edit')->middleware(['auth', 'admin']);
Route::put('/admin/santri/update/{santri}', 'Admin\SantriController@update')->name('admin.santri.update')->middleware(['auth', 'admin']);
Route::put('/admin/santri/activate/{santri}', 'Admin\SantriController@activate')->name('admin.santri.act')->middleware(['auth', 'admin']);
Route::delete('/admin/santri/deactivate/{santri}', 'Admin\SantriController@deactivate')->name('admin.santri.deact')->middleware(['auth', 'admin']);
