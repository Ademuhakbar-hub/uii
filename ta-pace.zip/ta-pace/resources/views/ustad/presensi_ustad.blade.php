@extends('layouts.app')

@push('style')
    <link href="{{ asset('css/bootstrap-datepicker.min.css') }}" rel="stylesheet">
@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('ustad.home') }}">Beranda</a></li>
    <li class="breadcrumb-item active" aria-current="page">Presensi Ustad</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Presensi Ustad</h2>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="data-tab" data-bs-toggle="tab" data-bs-target="#data" type="button" role="tab" aria-controls="data" aria-selected="true">Data</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="graph-tab" data-bs-toggle="tab" data-bs-target="#graph" type="button" role="tab" aria-controls="graph" aria-selected="false">Grafik</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="data" role="tabpanel" aria-labelledby="data-tab">
                <h4 class="mt-3 border-bottom border-1 border-primary">Tambah Presensi Ustad</h4>
                @if ($message = Session::get('success'))
                    <div class="alert alert-success alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                @if ($message = Session::get('error'))
                    <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                <form action="{{ route('ustad.presensi.add') }}" method="POST" autocomplete="off">
                    @csrf
                    <div class="row my-3">
                        <label for="tanggal" class="col-md-2 col-form-label">Tanggal</label>
                        <div class="col-md-4">
                            <input type="text" id="tanggal" class="form-control-plaintext" value="{{ Carbon\Carbon::now()->locale('id')->isoFormat('D MMMM Y') }}" readonly>
                        </div>
                    </div>
                    {{-- <fieldset class="row mb-3">
                        <legend class="col-form-label col-md-2 pt-0">Presensi</legend>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="hadirRadio" id="hadirRadio" value="1" required>
                                <label class="form-check-label" for="hadirRadio">
                                    Hadir
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="hadirRadio" id="tidakHadirRadio" value="0" required>
                                <label class="form-check-label" for="tidakHadirRadio">
                                    Tidak Hadir
                                </label>
                            </div>
                        </div>
                    </fieldset> --}}
                    <button type="submit" class="btn btn-secondary">Tambah Data Presensi</button>
                </form>
                <h4 class="mt-3 border-bottom border-1 border-primary">Sejarah Presensi Ustad</h4>
                <div class="table-responsive mt-3">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($presensiUstads->count() == 0)
                                <tr>
                                    <td colspan="2" class="text-center text-muted">Belum ada data untuk ditampilkan</td>
                                </tr>
                            @else
                                @foreach ($presensiUstads as $presensiUstad)
                                    <tr>
                                        <td>{{ $presensiUstad->date->locale('id')->isoFormat('dddd, D MMMM Y') }}</td>
                                        <td>
                                            @if ($presensiUstad->presence)
                                                <span class="badge bg-success"><i class="fas fa-check me-1"></i>Hadir</span>
                                            @else
                                                <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Tidak Hadir</span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="graph" role="tabpanel" aria-labelledby="graph-tab">
                <h4 class="mt-3 border-bottom border-1 border-primary">Grafik Presensi Ustad</h4>
                @if (count(array_unique($grafikHadir)) === 1 && count(array_unique($grafikTidakHadir)) === 1)
                    <div class="alert alert-warning alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>Belum ada data untuk ditampilkan</strong>
                    </div>
                @endif
                <canvas id="myChart" height="100"></canvas>
            </div>
        </div>

        {{-- <form action="{{ route('ustad.presensi') }}" method="GET" autocomplete="off">
            <div class="row mt-3 align-items-center">
                <div class="col-auto">
                    <label for="month" class="col-form-label">Bulan</label>
                </div>
                <div class="col-auto">
                    <input type="text" id="month" name="month" class="form-control">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-secondary">Perbarui</button>
                </div>
            </div>
        </form>
        <div class="table-responsive mt-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th class="text-center" colspan="10">
                            <h4>{{ $monthName }}</h4>
                        </th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <tr>
                        <td colspan="2"><b>Senin</b></td>
                        <td colspan="2"><b>Selasa</b></td>
                        <td colspan="2"><b>Rabu</b></td>
                        <td colspan="2"><b>Kamis</b></td>
                        <td colspan="2"><b>Jum'at</b></td>
                    </tr>
                    @switch($startTab)
                        @case(2)
                            <tr><td colspan="2"></td>
                            @break
                        @case(3)
                            <tr><td colspan="4"></td>
                            @break
                        @case(4)
                            <tr><td colspan="6"></td>
                            @break
                        @case(5)
                            <tr><td colspan="8"></td>
                            @break
                    @endswitch
                    @php
                        $j = $startTab;
                    @endphp
                    @for ($i = $startDate; $i <= $endDate; $i++)
                        @if ($j == 1)
                            <tr>
                        @endif
                        <td>{{ $i }}</td>
                        <td>
                            <b>
                                @if ($presensiUstads->whereDay('date', $i)->first() != null)
                                    @if ($presensiUstads->whereDay('date', $i)->first()->presence)
                                        <i class="fas fa-check"></i>
                                    @else
                                        <i class="fas fa-times"></i>
                                    @endif
                                @else
                                    <i class="fas fa-minus"></i>
                                @endif
                            </b>
                        </td>
                        @if ($j == 5)
                            </tr>
                            @php
                                $j = 1;
                                $i = $i + 2;
                            @endphp
                        @else
                            @php
                                $j++;
                            @endphp
                        @endif
                    @endfor
                </tbody>
            </table>
        </div> --}}
        {{-- <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="sejarah-presensi-tab" data-bs-toggle="tab" data-bs-target="#sejarahPresensi" type="button" role="tab" aria-controls="sejarahPresensi" aria-selected="true">Sejarah Presensi Ustad</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tambah-presensi-tab" data-bs-toggle="tab" data-bs-target="#tambahPresensi" type="button" role="tab" aria-controls="tambahPresensi" aria-selected="false">Tambah Presensi Ustad</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="sejarahPresensi" role="tabpanel" aria-labelledby="sejarah-presensi-tab">
                <h2 class="mt-3 border-bottom border-3 border-secondary">Sejarah Presensi Ustad</h2>

            </div>
            <div class="tab-pane fade" id="tambahPresensi" role="tabpanel" aria-labelledby="tambah-presensi-tab">
                <h2 class="mt-3 border-bottom border-3 border-secondary">Tambah Presensi Ustad</h2>

            </div>
        </div> --}}
    </div>
@endsection

@push('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script>
    <script src="{{ asset('js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-datepicker.id.min.js') }}"></script>
    <script>
        // $('#month').datepicker({
        //     autoclose: true,
        //     format: 'MM yyyy',
        //     startView: 1,
        //     minViewMode: 1,
        //     endDate: '0d',
        //     orientation: 'bottom',
        // });
        // $('#tanggal').datepicker({
        //     autoclose: true,
        //     format: 'dd-mm-yyyy',
        //     language: 'id',
        //     endDate: '0d',
        //     orientation: 'bottom',
        //     daysOfWeekDisabled: '0,6',
        // });
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
                datasets: [{
                    label: 'Hadir',
                    data: [
                        @foreach ($grafikHadir as $hadir)
                            {{ $hadir }},
                        @endforeach
                    ],
                    backgroundColor: [
                        'rgba(4, 49, 127, 1)',
                    ],
                },{
                    label: 'Tidak Hadir',
                    data: [
                        @foreach ($grafikTidakHadir as $tidakHadir)
                            {{ $tidakHadir }},
                        @endforeach
                    ],
                    backgroundColor: [
                        'rgba(246, 211, 0, 1)',
                    ],
                }]
            },
            options: {
                scales: {
                    y: {
                        suggestedMax: 30,
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
@endpush
