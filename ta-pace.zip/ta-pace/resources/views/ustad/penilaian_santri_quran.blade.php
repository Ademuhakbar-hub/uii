@extends('layouts.app')

@push('style')
    <link href="{{ asset('css/bootstrap-datepicker.min.css') }}" rel="stylesheet">
@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('ustad.home') }}">Beranda</a></li>
    <li class="breadcrumb-item active" aria-current="page">Penilaian Santri</li>
    <li class="breadcrumb-item active" aria-current="page">Al-Qur'an</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Penilaian Santri</h2>
        <ul class="nav nav-tabs mt-3">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page">Al-Qur'an</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('ustad.santri.penilaian.iqro') }}">Iqro</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('ustad.santri.penilaian.hafalan') }}">Hafalan</a>
            </li>
        </ul>
        <h4 class="mt-3 border-bottom border-1 border-primary">Tambah Penilaian Santri</h4>
        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        @if ($message = Session::get('error'))
            <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <form action="{{ route('ustad.santri.penilaian.quran.add') }}" method="POST" autocomplete="off">
            @csrf
            <div class="row my-3">
              <label for="santri" class="col-md-2 col-form-label">Nama Santri</label>
              <div class="col-md-4">
                <select class="form-select" aria-label="Pilih Santri" id="santri" name="santri" required>
                    <option disabled selected>Pilih Santri</option>
                    @foreach ($santris as $santri)
                        <option value="{{ $santri->id }}">{{ $santri->name }}</option>
                    @endforeach
                </select>
              </div>
            </div>
            <div class="row mb-3">
                <label for="tanggal" class="col-md-2 col-form-label">Tanggal</label>
                <div class="col-md-4">
                    <input type="text" id="tanggal" name="tanggal" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="keterangan" class="col-md-2 col-form-label">Keterangan</label>
                <div class="col-md-4">
                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3" placeholder="contoh: Al-Falah, 1-5, hal 5" required></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-secondary">Tambah Data</button>
        </form>
        <h4 class="mt-3 border-bottom border-1 border-primary">Sejarah Penilaian Santri</h4>
        <div class="table-responsive mt-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Nama Santri</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    @if ($penilaianSantriQurans->count() == 0)
                        <tr>
                            <td colspan="3" class="text-center text-muted">Belum ada data untuk ditampilkan</td>
                        </tr>
                    @else
                        @foreach ($penilaianSantriQurans as $penilaianSantriQuran)
                            <tr>
                                <td>{{ $penilaianSantriQuran->date->locale('id')->isoFormat('dddd, D MMMM Y') }}</td>
                                <td>{{ $penilaianSantriQuran->santri->name }}</td>
                                <td>{{ $penilaianSantriQuran->keterangan }}</td>
                            </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
    </div>
@endsection

@push('script')
    <script src="{{ asset('js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-datepicker.id.min.js') }}"></script>
    <script>
        $('#tanggal').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            language: 'id',
            endDate: '0d',
            orientation: 'bottom',
            daysOfWeekDisabled: '0,6',
        });
    </script>
@endpush
