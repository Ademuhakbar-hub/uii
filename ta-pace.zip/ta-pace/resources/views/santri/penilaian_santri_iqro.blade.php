@extends('layouts.app')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('ustad.home') }}">Beranda</a></li>
    <li class="breadcrumb-item active" aria-current="page">Penilaian Santri</li>
    <li class="breadcrumb-item active" aria-current="page">Iqro</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Penilaian Santri</h2>
        <ul class="nav nav-tabs mt-3">
            <li class="nav-item">
                <a class="nav-link" href="{{ route('penilaian.quran') }}">Al-Qur'an</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page">Iqro</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('penilaian.hafalan') }}">Hafalan</a>
            </li>
        </ul>
        <div class="table-responsive mt-3">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    @if ($penilaianSantriIqros->count() == 0)
                        <tr>
                            <td colspan="2" class="text-center text-muted">Belum ada data untuk ditampilkan</td>
                        </tr>
                    @else
                        @foreach ($penilaianSantriIqros as $penilaianSantriIqro)
                            <tr>
                                <td>{{ $penilaianSantriIqro->date->locale('id')->isoFormat('dddd, D MMMM Y') }}</td>
                                <td>{{ $penilaianSantriIqro->keterangan }}</td>
                            </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
    </div>
@endsection
