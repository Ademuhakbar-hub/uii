@extends('layouts.app')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Beranda</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Data Induk Santri</h2>
        <table class="table table-borderless mt-1">
            <tr>
                <th width="20%">Nama Lengkap</th>
                <td>: {{ auth()->user()->santri->name }}</td>
            </tr>
            <tr>
                <th width="20%">Tempat Lahir</th>
                <td>: {{ auth()->user()->santri->tempat_lahir }}</td>
            </tr>
            <tr>
                <th width="20%">Tanggal Lahir</th>
                <td>: {{ auth()->user()->santri->tanggal_lahir->locale('id')->isoFormat('D MMMM Y') }}</td>
            </tr>
            <tr>
                <th width="20%">Jenis Kelamin</th>
                <td>: {{ auth()->user()->santri->jenis_kelamin }}</td>
            </tr>
            <tr>
                <th width="20%">Alamat</th>
                <td>: {{ auth()->user()->santri->alamat }}</td>
            </tr>
            <tr>
                <th width="20%">Pendidikan Terakhir</th>
                <td>: {{ auth()->user()->santri->pendidikan_terakhir }}</td>
            </tr>
            <tr>
                <th width="20%">Status</th>
                <td>:
                    @if (auth()->user()->santri->status)
                        <span class="badge bg-success">Aktif</span>
                    @else
                        <span class="badge bg-danger">Tidak Aktif</span>
                    @endif
                </td>
            </tr>
            <tr>
                <th width="20%">No HP</th>
                <td>: {{ auth()->user()->santri->no_hp }}</td>
            </tr>
        </table>
        {{-- <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="data-induk-tab" data-bs-toggle="tab" data-bs-target="#dataInduk" type="button" role="tab" aria-controls="dataInduk" aria-selected="true">Data Induk Santri</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="ubah-data-tab" data-bs-toggle="tab" data-bs-target="#ubahData" type="button" role="tab" aria-controls="ubahData" aria-selected="false">Ubah Data Induk</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="ubah-password-tab" data-bs-toggle="tab" data-bs-target="#ubahPassword" type="button" role="tab" aria-controls="ubahPassword" aria-selected="false">Ubah Password</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="dataInduk" role="tabpanel" aria-labelledby="data-induk-tab">

            </div>
            <div class="tab-pane fade" id="ubahData" role="tabpanel" aria-labelledby="ubah-data-tab">
                <h2 class="mt-3 border-bottom border-3 border-secondary">Ubah Data Induk</h2>
            </div>
            <div class="tab-pane fade" id="ubahPassword" role="tabpanel" aria-labelledby="ubah-password-tab">
                <h2 class="mt-3 border-bottom border-3 border-secondary">Ubah Password</h2>
            </div>
        </div> --}}
    </div>
@endsection
