@extends('layouts.app')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('home') }}">Beranda</a></li>
    <li class="breadcrumb-item active" aria-current="page">Presensi Santri</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Presensi Santri</h2>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="data-tab" data-bs-toggle="tab" data-bs-target="#data" type="button" role="tab" aria-controls="data" aria-selected="true">Data</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="graph-tab" data-bs-toggle="tab" data-bs-target="#graph" type="button" role="tab" aria-controls="graph" aria-selected="false">Grafik</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="data" role="tabpanel" aria-labelledby="data-tab">
                <div class="table-responsive mt-3">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($presensiSantris->count() == 0)
                                <tr>
                                    <td colspan="3" class="text-center text-muted">Belum ada data untuk ditampilkan</td>
                                </tr>
                            @else
                                @foreach ($presensiSantris as $presensiSantri)
                                    <tr>
                                        <td>{{ $presensiSantri->date->locale('id')->isoFormat('dddd, D MMMM Y') }}</td>
                                        <td>
                                            @if ($presensiSantri->presence)
                                                <span class="badge bg-success"><i class="fas fa-check me-1"></i>Hadir</span>
                                            @else
                                                <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Tidak Hadir</span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="graph" role="tabpanel" aria-labelledby="graph-tab">
                @if (count(array_unique($grafikHadir)) === 1 && count(array_unique($grafikTidakHadir)) === 1)
                    <div class="alert alert-warning alert-block alert-dismissible" role="alert">
                        <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>Belum ada data untuk ditampilkan</strong>
                    </div>
                @endif
                <canvas id="myChart" height="100"></canvas>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script>
    <script>
        const ctx = document.getElementById('myChart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
                datasets: [{
                    label: 'Hadir',
                    data: [
                        @foreach ($grafikHadir as $hadir)
                            {{ $hadir }},
                        @endforeach
                    ],
                    backgroundColor: [
                        'rgba(4, 49, 127, 1)',
                    ],
                },{
                    label: 'Tidak Hadir',
                    data: [
                        @foreach ($grafikTidakHadir as $tidakHadir)
                            {{ $tidakHadir }},
                        @endforeach
                    ],
                    backgroundColor: [
                        'rgba(246, 211, 0, 1)',
                    ],
                }]
            },
            options: {
                scales: {
                    y: {
                        suggestedMax: 30,
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
@endpush
