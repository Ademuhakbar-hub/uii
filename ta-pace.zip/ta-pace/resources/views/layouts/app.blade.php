<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name') }}</title>
        <link rel="icon" href="{{ asset('favicon.png') }}" type="image/png">

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        @stack('style')
    </head>
    <body class="bg-light">
        @include('layouts.navbar')
        <main class="container-fluid mt-5 pt-4">
            <div class="card-body bg-white">
                <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        @yield('breadcrumb')
                        {{-- <li class="breadcrumb-item"><a href="#">Library</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Data</li> --}}
                    </ol>
                </nav>
            </div>
            <div class="row mt-3">
                @include('layouts.sidebar')
                <div class="col-md-9">
                    @yield('content')
                </div>
            </div>
        </main>
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="logoutModalLabel">Keluar dari Sistem</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Anda yakin akan keluar dari sistem?
                    </div>
                    <div class="modal-footer border-top-0">
                        <a href="#" class="btn btn-light" data-bs-dismiss="modal">Batal</a>
                        <a href="{{ route('logout') }}" class="btn btn-primary"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            Keluar
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                </div>
            </div>
        </div>
        @stack('modal')
        <!-- Scripts -->
        <script src="{{ asset('js/app.js') }}"></script>
        @stack('script')
    </body>
</html>
