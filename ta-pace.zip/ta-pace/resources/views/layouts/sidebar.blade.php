<div class="d-none d-md-block col-md-3">
    <div class="card card-body">
        <ul class="nav nav-pills flex-column">
            @switch(auth()->user()->role)
                @case('admin')
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('admin.home') ? ' active' : '' }}" href="{{ route('admin.home') }}">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('admin.ustad*') ? ' active' : '' }}" href="{{ route('admin.ustad') }}">Kelola Ustad</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('admin.santri*') ? ' active' : '' }}" href="{{ route('admin.santri') }}">Kelola Santri</a>
                    </li>
                    {{-- <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled">Disabled</a>
                    </li> --}}
                    @break
                @case('ustad')
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('ustad.home') ? ' active' : '' }}" href="{{ route('ustad.home') }}">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('ustad.presensi') ? ' active' : '' }}" href="{{ route('ustad.presensi') }}">Presensi Ustad</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('ustad.santri.presensi') ? ' active' : '' }}" href="{{ route('ustad.santri.presensi') }}">Presensi Santri</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('ustad.santri.penilaian*') ? ' active' : '' }}" href="{{ route('ustad.santri.penilaian.quran') }}">Penilaian Santri</a>
                    </li>
                    @break
                @default
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('home') ? ' active' : '' }}" href="{{ route('home') }}">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('presensi') ? ' active' : '' }}" href="{{ route('presensi') }}">Presensi Santri</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link{{ Route::is('penilaian*') ? ' active' : '' }}" href="{{ route('penilaian.quran') }}">Penilaian Santri</a>
                    </li>
            @endswitch
        </ul>
    </div>
</div>
