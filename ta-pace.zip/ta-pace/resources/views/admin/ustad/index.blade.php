@extends('layouts.app')

@push('style')
    <link rel="stylesheet" type="text/css" href="{{ asset('css/dataTables.bootstrap5.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/responsive.dataTables.min.css')}}">
@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.home') }}">Dashboard</a></li>
    <li class="breadcrumb-item active" aria-current="page">Kelola Ustad</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Kelola Ustad</h2>
        <h4 class="mt-3 border-bottom border-1 border-primary">Daftar Ustad</h4>
        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <div class="text-end">
            <a href="{{ route('admin.ustad.create') }}" class="btn btn-primary">Tambah Data</a>
        </div>
        <div class="mt-3">
            <table class="table table-hover table-bordered display responsive nowrap" width="100%" id="ustadTable">
                <thead>
                    <tr>
                        <th>Nama Ustad</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($ustads as $ustad)
                        <tr>
                            <td>{{ $ustad->name }}</td>
                            <td>{{ $ustad->user->username }}</td>
                            <td>{{ $ustad->user->email }}</td>
                            <td>
                                @if ($ustad->status)
                                    <span class="badge bg-success">Aktif</span>
                                @else
                                    <span class="badge bg-danger">Tidak Aktif</span>
                                @endif
                            </td>
                            <td>
                                @if ($ustad->status)
                                    <a href="{{ route('admin.ustad.show', $ustad->id) }}" class="btn btn-sm btn-light">Detail</a>
                                    <a href="{{ route('admin.ustad.edit', $ustad->id) }}" class="btn btn-sm btn-secondary">Ubah</a>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deactModal" data-bs-ustadId="{{ route('admin.ustad.deact', $ustad->id) }}" data-bs-ustadName="{{ $ustad->name }}">
                                        Nonaktifkan
                                    </button>
                                @else
                                    <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#actModal"  data-bs-ustadId="{{ route('admin.ustad.act', $ustad->id) }}" data-bs-ustadName="{{ $ustad->name }}">
                                        Aktifkan
                                    </button>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

@push('modal')
    <div class="modal fade" id="actModal" tabindex="-1" aria-labelledby="actModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="actModalLabel">Aktifkan Ustad?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" id="actForm">
                    @method('PUT')
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="actName" class="col-form-label">Anda yakin akan mengaktifkan ustad atas nama</label>
                            <input type="text" class="form-control-plaintext" id="actName" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Aktifkan Ustad</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="deactModal" tabindex="-1" aria-labelledby="deactModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deactModalLabel">Nonaktifkan Ustad?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" id="deactForm">
                    @method('DELETE')
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="deactName" class="col-form-label">Anda yakin akan menonaktifkan ustad atas nama</label>
                            <input type="text" class="form-control-plaintext" id="deactName" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Nonaktifkan Ustad</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endpush

@push('script')
    <script type="text/javascript" charset="utf8" src="{{ asset('js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" charset="utf8" src="{{ asset('js/dataTables.bootstrap5.min.js') }}"></script>
    <script type="text/javascript" charset="utf8" src="{{ asset('js/dataTables.responsive.min.js') }}"></script>
    <script>
        $('#ustadTable').DataTable({
            responsive: true,
            language: {
                url: '{{ asset('id.json') }}',
            },
        });
        var actModal = document.getElementById('actModal')
        actModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget
            var id = button.getAttribute('data-bs-ustadId')
            var name = button.getAttribute('data-bs-ustadName')

            var actForm = actModal.querySelector('#actForm')
            var actName = actModal.querySelector('#actName')

            actForm.action = id
            actName.value = name
        });
        var deactModal = document.getElementById('deactModal')
        deactModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget
            var id = button.getAttribute('data-bs-ustadId')
            var name = button.getAttribute('data-bs-ustadName')

            var deactForm = deactModal.querySelector('#deactForm')
            var deactName = deactModal.querySelector('#deactName')

            deactForm.action = id
            deactName.value = name
        });
    </script>
@endpush
