@extends('layouts.app')

@push('style')
    <link href="{{ asset('css/bootstrap-datepicker.min.css') }}" rel="stylesheet">
@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.home') }}">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.ustad') }}">Kelola Ustad</a></li>
    <li class="breadcrumb-item active" aria-current="page">Ubah Ustad</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Kelola Ustad</h2>
        <h4 class="mt-3 border-bottom border-1 border-primary">Ubah Ustad ID-{{ $ustad->id }}</h4>
        @if ($message = Session::get('error'))
            <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <form action="{{ route('admin.ustad.update', $ustad->id) }}" method="POST" autocomplete="off">
            @csrf
            @method('PUT')
            <div class="row my-3">
                <label for="name" class="col-md-2 col-form-label">Nama</label>
                <div class="col-md-4">
                    <input type="text" id="name" name="name" class="form-control" value="{{ $ustad->name }}" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="tempat_lahir" class="col-md-2 col-form-label">Tempat Lahir</label>
                <div class="col-md-4">
                    <input type="text" id="tempat_lahir" name="tempat_lahir" class="form-control" value="{{ $ustad->tempat_lahir }}" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="tanggal_lahir" class="col-md-2 col-form-label">Tanggal Lahir</label>
                <div class="col-md-4">
                    <input type="text" id="tanggal_lahir" name="tanggal_lahir" class="form-control" value="{{ $ustad->tanggal_lahir->format('d-m-Y') }}" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="jenis_kelamin" class="col-md-2 col-form-label">Jenis Kelamin</label>
                <div class="col-md-4">
                    <select class="form-select" aria-label="Pilih Jenis Kelamin" id="jenis_kelamin" name="jenis_kelamin" required>
                        <option disabled selected>Pilih Jenis Kelamin</option>
                        <option value="Laki-laki"{{ $ustad->jenis_kelamin == 'Laki-laki' ? ' selected' : '' }}>Laki-laki</option>
                        <option value="Perempuan"{{ $ustad->jenis_kelamin == 'Perempuan' ? ' selected' : '' }}>Perempuan</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="alamat" class="col-md-2 col-form-label">Alamat</label>
                <div class="col-md-4">
                    <textarea class="form-control" id="alamat" name="alamat" rows="3" required>{{ $ustad->alamat }}</textarea>
                </div>
            </div>
            <div class="row mb-3">
                <label for="pendidikan_terakhir" class="col-md-2 col-form-label">Pendidikan Terakhir</label>
                <div class="col-md-4">
                    <select class="form-select" aria-label="Pilih Pendidikan Terakhir" id="pendidikan_terakhir" name="pendidikan_terakhir" required>
                        <option disabled selected>Pilih Pendidikan Terakhir</option>
                        <option value="SMA"{{ $ustad->pendidikan_terakhir == 'SMA' ? ' selected' : '' }}>SMA</option>
                        <option value="S1"{{ $ustad->pendidikan_terakhir == 'S1' ? ' selected' : '' }}>S1</option>
                        <option value="S2"{{ $ustad->pendidikan_terakhir == 'S2' ? ' selected' : '' }}>S2</option>
                        <option value="S3"{{ $ustad->pendidikan_terakhir == 'S3' ? ' selected' : '' }}>S3</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="no_hp" class="col-md-2 col-form-label">No HP</label>
                <div class="col-md-4">
                    <input type="text" id="no_hp" name="no_hp" class="form-control" value="{{ $ustad->no_hp }}" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Perbarui Data</button>
        </form>
    </div>
@endsection

@push('script')
    <script src="{{ asset('js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-datepicker.id.min.js') }}"></script>
    <script>
        $('#tanggal_lahir').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            language: 'id',
            endDate: '0d',
            orientation: 'bottom',
        });
    </script>
@endpush
