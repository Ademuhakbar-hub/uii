@extends('layouts.app')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.home') }}">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.santri') }}">Kelola Santri</a></li>
    <li class="breadcrumb-item active" aria-current="page">Detail Santri</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Kelola Santri</h2>
        <h4 class="mt-3 border-bottom border-1 border-primary">Detail Santri ID-{{ $santri->id }}</h4>
        @if ($message = Session::get('success'))
            <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <div class="text-end">
            <a href="{{ route('admin.santri.edit', $santri->id) }}" class="btn btn-secondary">Ubah Data</a>
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deactModal">
                Nonaktifkan
            </button>
        </div>
        <form>
            <div class="row my-3">
                <label for="username" class="col-md-2 col-form-label">Username</label>
                <div class="col-md-4">
                    <input type="text" id="username" class="form-control-plaintext" value="{{ $santri->user->username }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="email" class="col-md-2 col-form-label">E-mail</label>
                <div class="col-md-4">
                    <input type="text" id="email" class="form-control-plaintext" value="{{ $santri->user->email }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="name" class="col-md-2 col-form-label">Nama</label>
                <div class="col-md-4">
                    <input type="text" id="name" class="form-control-plaintext" value="{{ $santri->name }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="tempat_lahir" class="col-md-2 col-form-label">Tempat Lahir</label>
                <div class="col-md-4">
                    <input type="text" id="tempat_lahir" class="form-control-plaintext" value="{{ $santri->tempat_lahir }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="tanggal_lahir" class="col-md-2 col-form-label">Tanggal Lahir</label>
                <div class="col-md-4">
                    <input type="text" id="tanggal_lahir" class="form-control-plaintext" value="{{ $santri->tanggal_lahir->locale('id')->isoFormat('D MMMM Y') }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="jenis_kelamin" class="col-md-2 col-form-label">Jenis Kelamin</label>
                <div class="col-md-4">
                    <input type="text" id="jenis_kelamin" class="form-control-plaintext" value="{{ $santri->jenis_kelamin }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="alamat" class="col-md-2 col-form-label">Alamat</label>
                <div class="col-md-4">
                    <textarea class="form-control-plaintext" id="alamat" rows="3" readonly>{{ $santri->alamat }}</textarea>
                </div>
            </div>
            <div class="row mb-3">
                <label for="pendidikan_terakhir" class="col-md-2 col-form-label">Pendidikan Terakhir</label>
                <div class="col-md-4">
                    <input type="text" id="pendidikan_terakhir" class="form-control-plaintext" value="{{ $santri->pendidikan_terakhir }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="no_hp" class="col-md-2 col-form-label">No HP</label>
                <div class="col-md-4">
                    <input type="text" id="no_hp" class="form-control-plaintext" value="{{ $santri->no_hp }}" readonly>
                </div>
            </div>
            <div class="row mb-3">
                <label for="ustad" class="col-md-2 col-form-label">Nama Ustad Pengampu</label>
                <div class="col-md-4">
                    <input type="text" id="ustad" class="form-control-plaintext" value="{{ $santri->ustad->name }}">
                </div>
            </div>
        </form>
    </div>
@endsection

@push('modal')
    <div class="modal fade" id="deactModal" tabindex="-1" aria-labelledby="deactModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deactModalLabel">Nonaktifkan Santri?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('admin.santri.deact', $santri->id) }}" method="POST" id="deactForm">
                    @method('DELETE')
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="deactName" class="col-form-label">Anda yakin akan menonaktifkan santri atas nama</label>
                            <input type="text" class="form-control-plaintext" id="deactName" value="{{ $santri->name }}" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Nonaktifkan Santri</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endpush
