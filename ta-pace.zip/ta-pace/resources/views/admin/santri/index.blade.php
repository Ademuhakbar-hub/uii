@extends('layouts.app')

@push('style')
    <link rel="stylesheet" type="text/css" href="{{ asset('css/dataTables.bootstrap5.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/responsive.dataTables.min.css')}}">
@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.home') }}">Dashboard</a></li>
    <li class="breadcrumb-item active" aria-current="page">Kelola Santri</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Kelola Santri</h2>
        <h4 class="mt-3 border-bottom border-1 border-primary">Daftar Santri</h4>
        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <div class="text-end">
            <a href="{{ route('admin.santri.create') }}" class="btn btn-primary">Tambah Data</a>
        </div>
        <div class="mt-3">
            <table class="table table-hover table-bordered display responsive nowrap" width="100%" id="santriTable">
                <thead>
                    <tr>
                        <th>Nama Santri</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Nama Ustad Pengampu</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($santris as $santri)
                        <tr>
                            <td>{{ $santri->name }}</td>
                            <td>{{ $santri->user->username }}</td>
                            <td>{{ $santri->user->email }}</td>
                            <td>{{ $santri->ustad->name }}</td>
                            <td>
                                @if ($santri->status)
                                    <span class="badge bg-success">Aktif</span>
                                @else
                                    <span class="badge bg-danger">Tidak Aktif</span>
                                @endif
                            </td>
                            <td>
                                @if ($santri->status)
                                    <a href="{{ route('admin.santri.show', $santri->id) }}" class="btn btn-sm btn-light">Detail</a>
                                    <a href="{{ route('admin.santri.edit', $santri->id) }}" class="btn btn-sm btn-secondary">Ubah</a>
                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deactModal" data-bs-santriId="{{ route('admin.santri.deact', $santri->id) }}" data-bs-santriName="{{ $santri->name }}">
                                        Nonaktifkan
                                    </button>
                                @else
                                    <button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#actModal"  data-bs-santriId="{{ route('admin.santri.act', $santri->id) }}" data-bs-santriName="{{ $santri->name }}">
                                        Aktifkan
                                    </button>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

@push('modal')
    <div class="modal fade" id="actModal" tabindex="-1" aria-labelledby="actModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="actModalLabel">Aktifkan Santri?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" id="actForm">
                    @method('PUT')
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="actName" class="col-form-label">Anda yakin akan mengaktifkan santri atas nama</label>
                            <input type="text" class="form-control-plaintext" id="actName" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Aktifkan Santri</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="deactModal" tabindex="-1" aria-labelledby="deactModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deactModalLabel">Nonaktifkan Santri?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" id="deactForm">
                    @method('DELETE')
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="deactName" class="col-form-label">Anda yakin akan menonaktifkan santri atas nama</label>
                            <input type="text" class="form-control-plaintext" id="deactName" readonly>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Nonaktifkan Santri</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endpush

@push('script')
    <script type="text/javascript" charset="utf8" src="{{ asset('js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" charset="utf8" src="{{ asset('js/dataTables.bootstrap5.min.js') }}"></script>
    <script type="text/javascript" charset="utf8" src="{{ asset('js/dataTables.responsive.min.js') }}"></script>
    <script>
        $('#santriTable').DataTable({
            responsive: true,
            language: {
                url: '{{ asset('id.json') }}',
            },
        });
        var actModal = document.getElementById('actModal')
        actModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget
            var id = button.getAttribute('data-bs-santriId')
            var name = button.getAttribute('data-bs-santriName')

            var actForm = actModal.querySelector('#actForm')
            var actName = actModal.querySelector('#actName')

            actForm.action = id
            actName.value = name
        });
        var deactModal = document.getElementById('deactModal')
        deactModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget
            var id = button.getAttribute('data-bs-santriId')
            var name = button.getAttribute('data-bs-santriName')

            var deactForm = deactModal.querySelector('#deactForm')
            var deactName = deactModal.querySelector('#deactName')

            deactForm.action = id
            deactName.value = name
        });
    </script>
@endpush
