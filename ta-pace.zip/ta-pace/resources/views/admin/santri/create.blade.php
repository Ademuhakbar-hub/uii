@extends('layouts.app')

@push('style')
    <link href="{{ asset('css/bootstrap-datepicker.min.css') }}" rel="stylesheet">
@endpush

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.home') }}">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="{{ route('admin.santri') }}">Kelola Santri</a></li>
    <li class="breadcrumb-item active" aria-current="page">Tambah Santri</li>
@endsection

@section('content')
    <div class="card card-body">
        <h2 class="mt-3 border-bottom border-3 border-secondary">Kelola Santri</h2>
        <h4 class="mt-3 border-bottom border-1 border-primary">Tambah Santri</h4>
        @if ($message = Session::get('error'))
            <div class="alert alert-danger alert-block alert-dismissible" role="alert">
                <i class="fas fa-exclamation-circle"></i>&nbsp;<strong>{{ $message }}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif
        <form action="{{ route('admin.santri.store') }}" method="POST" autocomplete="off">
            @csrf
            <div class="row my-3">
                <label for="username" class="col-md-2 col-form-label">Username</label>
                <div class="col-md-4">
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="email" class="col-md-2 col-form-label">E-mail</label>
                <div class="col-md-4">
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="password" class="col-md-2 col-form-label">Password</label>
                <div class="col-md-4">
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="name" class="col-md-2 col-form-label">Nama</label>
                <div class="col-md-4">
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="tempat_lahir" class="col-md-2 col-form-label">Tempat Lahir</label>
                <div class="col-md-4">
                    <input type="text" id="tempat_lahir" name="tempat_lahir" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="tanggal_lahir" class="col-md-2 col-form-label">Tanggal Lahir</label>
                <div class="col-md-4">
                    <input type="text" id="tanggal_lahir" name="tanggal_lahir" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="jenis_kelamin" class="col-md-2 col-form-label">Jenis Kelamin</label>
                <div class="col-md-4">
                    <select class="form-select" aria-label="Pilih Jenis Kelamin" id="jenis_kelamin" name="jenis_kelamin" required>
                        <option disabled selected>Pilih Jenis Kelamin</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="alamat" class="col-md-2 col-form-label">Alamat</label>
                <div class="col-md-4">
                    <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                </div>
            </div>
            <div class="row mb-3">
                <label for="pendidikan_terakhir" class="col-md-2 col-form-label">Pendidikan Terakhir</label>
                <div class="col-md-4">
                    <select class="form-select" aria-label="Pilih Pendidikan Terakhir" id="pendidikan_terakhir" name="pendidikan_terakhir" required>
                        <option disabled selected>Pilih Pendidikan Terakhir</option>
                        <option value="TK">TK</option>
                        <option value="SD Kelas 1">SD Kelas 1</option>
                        <option value="SD Kelas 2">SD Kelas 2</option>
                        <option value="SD Kelas 3">SD Kelas 3</option>
                        <option value="SD Kelas 4">SD Kelas 4</option>
                        <option value="SD Kelas 5">SD Kelas 5</option>
                        <option value="SD Kelas 6">SD Kelas 6</option>
                        <option value="SMP Kelas 1">SMP Kelas 1</option>
                        <option value="SMP Kelas 2">SMP Kelas 2</option>
                        <option value="SMP Kelas 3">SMP Kelas 3</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label for="no_hp" class="col-md-2 col-form-label">No HP</label>
                <div class="col-md-4">
                    <input type="text" id="no_hp" name="no_hp" class="form-control" required>
                </div>
            </div>
            <div class="row mb-3">
                <label for="ustad" class="col-md-2 col-form-label">Nama Ustad Pengampu</label>
                <div class="col-md-4">
                  <select class="form-select" aria-label="Pilih Ustad Pengampu" id="ustad" name="ustad" required>
                      <option disabled selected>Pilih Ustad Pengampu</option>
                      @foreach ($ustads as $ustad)
                          <option value="{{ $ustad->id }}">{{ $ustad->name }}</option>
                      @endforeach
                  </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Data</button>
        </form>
    </div>
@endsection

@push('script')
    <script src="{{ asset('js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-datepicker.id.min.js') }}"></script>
    <script>
        $('#tanggal_lahir').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            language: 'id',
            endDate: '0d',
            orientation: 'bottom',
        });
    </script>
@endpush
