@extends('layouts.app')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
@endsection

@section('content')
    <div class="card card-body">
        <div class="py-3">
            <h3 class="m-0">Selamat Datang </h3>
            <p class="mb-0">{{ auth()->user()->username }}</p>
        </div>
        <h2 class="mt-3"></h2>
    </div>
@endsection
